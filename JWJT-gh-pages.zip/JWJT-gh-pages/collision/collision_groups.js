//global collision groups
var collision_groups = new disjoint();
